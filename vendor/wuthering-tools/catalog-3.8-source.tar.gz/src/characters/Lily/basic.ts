export function getCharacterBasicInfo(): CharacterBasicInfo {
  return {
    name: "Lily",
    rarity: 5,
    weapon: "Pistols",
    avatarUrl: "Lily.png",
    gender: "female",
    element: "Spectro",
    image: "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Image/IconRolePile/T_IconRole_Pile_Lili_UI.webp",
    inherentSkillIcons: ["https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconLili/SP_IconLiliD1.webp","https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconLili/SP_IconLiliD2.webp"],
    signatureWeapon: "Lullaby",
    liveResultBarStats: ["totalHp", "totalCritRate", "totalCritDMG", "energyRegen"],
    suggestedWeapons: [
      { key: "Cadenza", label: "4*" },
    ],
  };
}
