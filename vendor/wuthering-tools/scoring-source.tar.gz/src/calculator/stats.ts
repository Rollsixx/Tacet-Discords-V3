import { isBuffActiveForStance } from "./stances";
import { getEnabledAdditionalBasePassives } from "../echoes/sets";

/**
 * Coerces to a finite number, defaulting to 0 otherwise. `addBuffs` sums
 * many stat sources together with "+=" — including `customBuffs`, which
 * comes straight from user-typed form fields (and, for saves persisted
 * before those fields were fixed to coerce on input, may still be a
 * string). A stray string silently turns "+=" into concatenation for the
 * rest of that stat's accumulation instead of raising a visible error, so
 * every value is normalized here before use rather than relying on each
 * field's own truthy/`*100` check (which doesn't protect flat fields like
 * ATK_FLAT, EnergyRegen, HealingBonus, ShieldBonus, or DMGDeepen).
 */
function n(value: unknown): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : 0;
}

export const getInitStats = (providedFullStats: any = {}) => {
  let stats = {
    attackPercent: 0,
    hpPercent: 0,
    defPercent: 0,
    attackFlat: 0,
    hpFlat: 0,
    defFlat: 0,
    critRate: 5,
    critDMG: 150,
    dmgBonus: 0,
    energyRegen: 1,
    healingBonus: 0,
    shieldBonus: 0,
    basicAttackDMGBonus: 0,
    heavyAttackDMGBonus: 0,
    resonanceSkillDMGBonus: 0,
    introSkillDMGBonus: 0,
    outroSkillDMGBonus: 0,
    resonanceLiberationDMGBonus: 0,
    echoDMGBonus: 0,
    glacio: 0,
    fusion: 0,
    electro: 0,
    aero: 0,
    spectro: 0,
    havoc: 0,
    defIgnore: 0,
    bonusSpecificSkillDMGBonus: 0,
    totalDeepenEffect: 0,
    resistReduction: 0,
    coordinatedDmgBonus: 0,
  };

  if (providedFullStats) {
    stats = { ...stats, ...providedFullStats };
  }
  return stats;
};

export const addEchoBuffs = (
  source: any,
  target: any,
  returnCopy: boolean = false,
) => {
  // we make a clone to make sure we don't mutate the original
  // mostly used in the optimizer so we can have a constant base, and then layer on the echo buffs
  // without messing up the original state of stats
  if (returnCopy) {
    target = JSON.parse(JSON.stringify(target));
  }
  if (source) {
    target.attackPercent += n(source?.ATK);
    target.hpPercent += n(source?.HP);
    target.defPercent += n(source?.DEF);
    target.attackFlat += n(source?.ATK_FLAT);
    target.hpFlat += n(source?.HP_FLAT);
    target.defFlat += n(source?.DEF_FLAT);
    target.critRate += n(source?.CritRate);
    target.critDMG += n(source?.CritDMG);
    target.energyRegen += n(source?.EnergyRegen) / 100;
    target.healingBonus += n(source?.HealingBonus) / 100;
    target.basicAttackDMGBonus += n(source?.BasicAttackDMGBonus);
    target.heavyAttackDMGBonus += n(source?.HeavyAttackDMGBonus);
    target.resonanceSkillDMGBonus += n(source?.ResonanceSkillDMGBonus);
    target.resonanceLiberationDMGBonus += n(
      source?.ResonanceLiberationDMGBonus,
    );
    target.echoDMGBonus += n(source?.EchoDMGBonus);
    target.outroSkillDMGBonus += n(source?.OutroSkillDMGBonus);
    target.glacio += n(source?.Glacio);
    target.fusion += n(source?.Fusion);
    target.electro += n(source?.Electro);
    target.aero += n(source?.Aero);
    target.spectro += n(source?.Spectro);
    target.havoc += n(source?.Havoc);
    target.defIgnore += n(source?.DEFIgnore);
    target.bonusSpecificSkillDMGBonus += n(source?.BonusSpecificSkillDMGBonus);
    target.totalDeepenEffect += n(source?.TotalDeepenEffect);
    target.resistReduction += n(source?.ResistReduction);
    target.coordinatedDmgBonus += n(source?.CoordinatedDMGBonus);
    target.dmgBonus += n(source?.DMGBonus);

    if (source?.AllAttributeBonus) {
      const allAttributeBonus = n(source.AllAttributeBonus);
      target.basicAttackDMGBonus += allAttributeBonus;
      target.heavyAttackDMGBonus += allAttributeBonus;
      target.resonanceSkillDMGBonus += allAttributeBonus;
      target.resonanceLiberationDMGBonus += allAttributeBonus;
      target.introSkillDMGBonus += allAttributeBonus;
      target.outroSkillDMGBonus += allAttributeBonus;
    }
    if (source?.AllElementAttributeBonus) {
      const allElementAttributeBonus = n(source.AllElementAttributeBonus);
      target.glacio += allElementAttributeBonus;
      target.fusion += allElementAttributeBonus;
      target.electro += allElementAttributeBonus;
      target.aero += allElementAttributeBonus;
      target.spectro += allElementAttributeBonus;
      target.havoc += allElementAttributeBonus;
    }
  }
  if (returnCopy) {
    return target;
  }
};

export const addBuffs = (source: any, target: any) => {
  if (source) {
    target.attackPercent += n(source?.ATK) * 100;
    target.hpPercent += n(source?.HP) * 100;
    target.defPercent += n(source?.DEF) * 100;
    target.attackFlat += n(source?.ATK_FLAT);
    target.hpFlat += n(source?.HP_FLAT);
    target.defFlat += n(source?.DEF_FLAT);
    target.critRate += n(source?.CritRate) * 100;
    target.critDMG += n(source?.CritDMG) * 100;
    target.energyRegen += n(source?.EnergyRegen);
    target.healingBonus += n(source?.HealingBonus);
    target.shieldBonus += n(source?.ShieldBonus);
    target.basicAttackDMGBonus += n(source?.BasicAttackDMGBonus) * 100;
    target.heavyAttackDMGBonus += n(source?.HeavyAttackDMGBonus) * 100;
    target.resonanceSkillDMGBonus += n(source?.ResonanceSkillDMGBonus) * 100;
    target.introSkillDMGBonus += n(source?.IntroSkillDMGBonus) * 100;
    target.outroSkillDMGBonus += n(source?.OutroSkillDMGBonus) * 100;
    target.resonanceLiberationDMGBonus +=
      n(source?.ResonanceLiberationDMGBonus) * 100;
    target.echoDMGBonus += n(source?.EchoDMGBonus) * 100;
    target.glacio += n(source?.Glacio) * 100;
    target.fusion += n(source?.Fusion) * 100;
    target.electro += n(source?.Electro) * 100;
    target.aero += n(source?.Aero) * 100;
    target.spectro += n(source?.Spectro) * 100;
    target.havoc += n(source?.Havoc) * 100;
    target.defIgnore += n(source?.DEFIgnore) * 100;
    target.bonusSpecificSkillDMGBonus +=
      n(source?.BonusSpecificSkillDMGBonus) * 100;
    target.totalDeepenEffect += n(source?.DMGDeepen);
    target.resistReduction += n(source?.ResistReduction) * 100;

    if (source?.AllAttributeBonus) {
      const allAttributeBonus = n(source.AllAttributeBonus) * 100;
      target.basicAttackDMGBonus += allAttributeBonus;
      target.heavyAttackDMGBonus += allAttributeBonus;
      target.resonanceSkillDMGBonus += allAttributeBonus;
      target.resonanceLiberationDMGBonus += allAttributeBonus;
      target.introSkillDMGBonus += allAttributeBonus;
      target.outroSkillDMGBonus += allAttributeBonus;
    }
    if (source?.AllElementAttributeBonus) {
      const allElementAttributeBonus = n(source.AllElementAttributeBonus) * 100;
      target.glacio += allElementAttributeBonus;
      target.fusion += allElementAttributeBonus;
      target.electro += allElementAttributeBonus;
      target.aero += allElementAttributeBonus;
      target.spectro += allElementAttributeBonus;
      target.havoc += allElementAttributeBonus;
    }
    if (source?.AllResonanceDMG) {
      const allResonanceDMG = n(source.AllResonanceDMG) * 100;
      target.resonanceSkillDMGBonus += allResonanceDMG;
      target.resonanceLiberationDMGBonus += allResonanceDMG;
    }
  }
};

export const getElementDmgBonusByType = (
  element: string,
  providedStats: any,
  stats: any,
): number => {
  let val = 0;
  switch (element) {
    case "Glacio":
      val = providedStats?.glacio ?? stats.Glacio;
      break;
    case "Fusion":
      val = providedStats?.fusion ?? stats.Fusion;
      break;
    case "Electro":
      val = providedStats?.electro ?? stats.Electro;
      break;
    case "Aero":
      val = providedStats?.aero ?? stats.Aero;
      break;
    case "Spectro":
      val = providedStats?.spectro ?? stats.Spectro;
      break;
    case "Havoc":
      val = providedStats?.havoc ?? stats.Havoc;
      break;
  }

  return val / 100;
};

export const getDamageValByAttr = (
  attribute: string = "attack",
  providedStats: any,
  stats: any,
): number => {
  switch (attribute) {
    case "defense":
      return providedStats?.totalDef ?? stats.totalDef;
    case "hp":
      return providedStats?.totalHp ?? stats.totalHp;
    case "EnergyRegen":
      // we store the ER in decimal form, but for calculating damages based on ER
      // it uses the full amount (1.5 => 150%)
      const decimalEnergy = providedStats?.energyRegen ?? stats.energyRegen;
      const intEnergy = decimalEnergy * 100;
      return intEnergy;
    case "attack":
    default:
      return providedStats?.totalAtk ?? stats.totalAtk;
  }
};

export const getDamageTypeBonusByType = (
  type: string,
  providedStats: any,
  stats: any,
) => {
  let val = 0;
  switch (type) {
    case "Basic":
      val = providedStats?.basicAttackDMGBonus ?? stats.BasicAttackDMGBonus;
      break;
    case "Heavy":
      val = providedStats?.heavyAttackDMGBonus ?? stats.HeavyAttackDMGBonus;
      break;
    case "Skill":
      val =
        providedStats?.resonanceSkillDMGBonus ?? stats.ResonanceSkillDMGBonus;
      break;
    case "Intro":
      val = providedStats?.introSkillDMGBonus ?? stats.IntroSkillDMGBonus;
      break;
    case "Outro":
      val = providedStats?.outroSkillDMGBonus ?? stats.OutroSkillDMGBonus;
      break;
    case "Liberation":
      val =
        providedStats?.resonanceLiberationDMGBonus ??
        stats.ResonanceLiberationDMGBonus;
      break;
    case "Echo":
      val = providedStats?.echoDmgBonus ?? stats.EchoDMGBonus;
      break;
    // do not divide this by 100
    case "Healing":
      return providedStats?.healingBonus ?? stats.healingBonus;
    case "Shield":
      return providedStats?.shieldBonus ?? stats.shieldBonus;
  }

  return val / 100;
};

export const calcCharStats = (
  returnValue: any = false,
  injectStats: any = null,
  ignoreBuffs: any = {}, // e.g. {ignoreTeamBuffs: true}
  injectEchoStats: any = null,
  providedFullStats: any = null,
  characterStats: any = {},
  weaponData: any = {},
  charBuffsData: any = {},
  charResonanceChainsData: any = {},
  echoStats: any = {},
  customBuffs: any = {},
  teamBuffsData: any = {},
): any => {
  const { ignoreTeamBuffs, ignoreWeaponBuffs, ignoreEchoes } = ignoreBuffs;
  let stats = getInitStats(providedFullStats);
  let { baseHp = 0, baseAtk = 0, baseDef = 0 } = characterStats;
  let weaponAtk = 0;

  let weaponModifier: string | null = null;
  let weaponModifierValue: number = 0;
  let weaponPassiveData = {};

  if (charBuffsData && !providedFullStats) {
    addBuffs(charBuffsData, stats);
  }

  if (injectStats) {
    addBuffs(injectStats, stats);
  }

  if (charResonanceChainsData && !providedFullStats) {
    addBuffs(charResonanceChainsData, stats);
  }

  if (weaponData) {
    weaponAtk = weaponData.weaponAtk;
    weaponModifier = weaponData.weaponModifier;
    weaponModifierValue = weaponData.weaponModifierValue;
    weaponPassiveData = weaponData.weaponPassiveData ?? {};

    weaponPassiveData = Object.fromEntries(
      Object.entries(weaponPassiveData).filter(([_, v]) => v != null),
    );

    if (!ignoreWeaponBuffs && !providedFullStats) {
      addBuffs(weaponPassiveData, stats);
    }

    if (!providedFullStats) {
      switch (weaponModifier) {
        case "ATK":
          stats.attackPercent += weaponModifierValue * 100;
          break;
        case "HP":
          stats.hpPercent += weaponModifierValue * 100;
          break;
        case "DEF":
          stats.defPercent += weaponModifierValue * 100;
          break;
        case "CritRate":
          stats.critRate += weaponModifierValue * 100;
          break;
        case "CritDMG":
          stats.critDMG += weaponModifierValue * 100;
          break;
        case "EnergyRegen":
          stats.energyRegen += weaponModifierValue;
          break;
        case "HealingBonus":
          stats.healingBonus += weaponModifierValue;
          break;
      }
    }
  }

  if (echoStats && !ignoreEchoes && !providedFullStats) {
    addEchoBuffs(echoStats, stats);
  }

  if (injectEchoStats && !providedFullStats) {
    addEchoBuffs(injectEchoStats, stats);
  }

  if (customBuffs && !providedFullStats) {
    addBuffs(customBuffs, stats);
  }

  if (teamBuffsData && !ignoreTeamBuffs && !providedFullStats) {
    addBuffs(teamBuffsData, stats);
  }

  if (returnValue) {
    switch (returnValue) {
      case "All":
        const returnedStats: any = { ...stats };
        returnedStats.totalAtk =
          (baseAtk + weaponAtk) * (1 + stats.attackPercent / 100) +
          stats.attackFlat;
        returnedStats.totalHp =
          baseHp * (1 + stats.hpPercent / 100) + stats.hpFlat;
        returnedStats.totalDef =
          baseDef * (1 + stats.defPercent / 100) + stats.defFlat;
        returnedStats.totalCritRate = stats.critRate / 100;
        returnedStats.totalCritDMG = stats.critDMG / 100;
        returnedStats.DefIgnore = stats.defIgnore / 100;
        return returnedStats;
      case "HP":
        return baseHp * (1 + stats.hpPercent / 100) + stats.hpFlat;
      case "DEF":
        return baseDef * (1 + stats.defPercent / 100) + stats.defFlat;
      case "ATK":
      default:
        return (
          (baseAtk + weaponAtk) * (1 + stats.attackPercent / 100) +
          stats.attackFlat
        );
    }
  }
  const returnedStats: any = { ...stats };
  returnedStats.totalAtk =
    (baseAtk + weaponAtk) * (1 + stats.attackPercent / 100) + stats.attackFlat;
  returnedStats.totalHp = baseHp * (1 + stats.hpPercent / 100) + stats.hpFlat;
  returnedStats.totalDef =
    baseDef * (1 + stats.defPercent / 100) + stats.defFlat;
  returnedStats.totalCritRate = stats.critRate / 100;
  returnedStats.totalCritDMG = stats.critDMG / 100;
  returnedStats.DefIgnore = stats.defIgnore / 100;
  return returnedStats;
};

/** Denia Etched Colors: bonus Tune Break Boost from Off-Tune Buildup Rate over 100%. */
export const computeDeniaOffTuneBuildupTuneBreakBoost = (
  offTuneBuildupRate: number,
): number => {
  if (offTuneBuildupRate < 100) {
    return 0;
  }
  return Math.min((offTuneBuildupRate - 100) * 0.008, 0.4);
};

export const computeTotalTuneBreakBoost = ({
  baseTuneBreakBoost = 0,
  selfBuffs = {},
  resonanceChainsBuffs = {},
  teamBuffs = {},
  echoStats = {},
}: {
  baseTuneBreakBoost?: number;
  selfBuffs?: { tuneBreakBoost?: number };
  resonanceChainsBuffs?: { tuneBreakBoost?: number };
  teamBuffs?: { tuneBreakBoost?: number };
  echoStats?: { tuneBreakBoost?: number };
} = {}): number => {
  const tuneBreakBoostSelf = selfBuffs?.tuneBreakBoost ?? 0;
  const tuneBreakBoostResonanceChains =
    resonanceChainsBuffs?.tuneBreakBoost ?? 0;
  const tuneBreakBoostTeam = teamBuffs?.tuneBreakBoost ?? 0;
  const tuneBreakBoostEchoes = echoStats?.tuneBreakBoost ?? 0;
  return (
    baseTuneBreakBoost +
    tuneBreakBoostSelf +
    tuneBreakBoostResonanceChains +
    tuneBreakBoostTeam +
    tuneBreakBoostEchoes / 100
  );
};

export const getResonanceChainBuffAttackTargets = (
  chainConfig: { [key: string]: unknown } | null | undefined,
  talentKeys: string[],
  configKey: string,
  defaultValue: string = "none",
): string[] => {
  const selectedTarget =
    (chainConfig?.[configKey] as string | undefined) ?? defaultValue;
  if (selectedTarget === "none") {
    return [];
  }
  // Legacy: "all" was removed in favor of per-attack / none selection
  if (selectedTarget === "all") {
    return talentKeys;
  }
  if (talentKeys.includes(selectedTarget)) {
    return [selectedTarget];
  }
  return [];
};

export const computeSelfBuffs = (
  buffsConfig: any = null,
  buffsCharInfo: any = null,
  resonanceChainsConfig: any = null,
  talentData: any = {},
  character: string = "",
  activeStance: string | null = null,
  enemy: { havocBaneStacks?: number } = {},
): any => {
  // find the buff in our char data
  if (!buffsCharInfo || buffsCharInfo.length <= 0) {
    return;
  }
  const data: any = {
    EnableAttack: [],
    specificTalentBuffs: {},
  };

  const modifySpecificTalents: any = [];
  // go through each buffsConfig, make sure it's enabled, then compute the buff
  const entries = Object.entries(buffsConfig) as [string, any][];
  for (const [key, buffData] of entries) {
    // skip if it's not enabled
    if (!buffData?.isEnabled) {
      continue;
    }
    const buffFromCharacter = buffsCharInfo.find(
      (buffItem: any) => buffItem.key === key,
    );
    if (!buffFromCharacter) {
      continue;
    }
    if (!isBuffActiveForStance(buffFromCharacter, activeStance)) {
      continue;
    }
    // Runs before the hasStacks stacks<=0 "continue" below so the delayed
    // proc stays selectable/enabled in rotations even at 0 Heart of Thunder
    // stacks consumed (it just deals 0 damage there, per the kit formula).
    if (character === "Hsin" && key === "ResonanceModeElectroFlareHeartOfThunderDelayedDMG") {
      data.EnableAttack.push("ResonanceModeElectroFlareHeartOfThunderDelayedDMG");
      data.specificTalentBuffs["HeartOfThunderDelayedDMG:heartOfThunderStacks"] =
        buffData?.stacks ?? 0;
    }
    const buff = JSON.parse(JSON.stringify(buffFromCharacter));

    const modifiersData = buff?.modifiers ?? [];
    let modifiers = JSON.parse(JSON.stringify(modifiersData));
    // character specifics modifications
    // If Lupa has s3 enabled, the ResistIgnore:Fusion buffs from InherentSkillApplauseofVictory & InherentSkillApplauseofVictoryFullFusionTeam are already taken care of
    if (
      character === "Lupa" &&
      (key === "InherentSkillApplauseofVictory" ||
        key === "InherentSkillApplauseofVictoryFullFusionTeam")
    ) {
      if (
        resonanceChainsConfig?.SequenceNode3WolflameHowlsinHerWakeIgnoreFusion
          ?.isEnabled
      ) {
        continue;
      }
    }
    // if Jiyan has ForteCircuitQingloongatWar2 enabled, ignore ForteCircuitQingloongatWar1
    // they're both self buffs, no resonance chains
    if (character === "Jiyan" && key === "ForteCircuitQingloongatWar1") {
      if (buffsConfig?.ForteCircuitQingloongatWar2?.isEnabled) {
        continue;
      }
    }
    // on Augusta, we change modifiers
    // this only applies to CrownofWills on Augusta
    if (character === "Augusta" && key === "CrownofWills") {
      // Check if resonance chain buffs are enabled and apply their effects
      const sequenceNode1 =
        resonanceChainsConfig?.SequenceNode1StainedinScorchedEarth;
      const sequenceNode2 =
        resonanceChainsConfig?.SequenceNode2CleansedinCrimsonWar;

      // Apply SequenceNode1 effects if enabled
      if (sequenceNode1?.isEnabled) {
        // Add CritDMG modifier if not already present
        const hasCritDMG = modifiers.some(
          (mod: any) => mod.modifier === "CritDMG",
        );
        if (!hasCritDMG) {
          modifiers.push({
            modifier: "CritDMG",
            modifierValue: 0.15,
          });
        }
      }

      // Apply SequenceNode2 effects if enabled
      if (sequenceNode2?.isEnabled) {
        // Add CritDMG modifier if not already present
        const hasCritDMG = modifiers.some(
          (mod: any) => mod.modifier === "CritRate",
        );
        if (!hasCritDMG) {
          modifiers.push({
            modifier: "CritRate",
            modifierValue: 0.2,
          });
        }
      }
    }

    // this only applies to Afterflame on Galbrena
    if (character === "Galbrena" && key === "Afterflame") {
      // Check if resonance chain buffs are enabled and apply their effects
      const sequenceNode1 =
        resonanceChainsConfig?.SequenceNode1HeartofDefianceEverAblaze;
      const sequenceNode6 =
        resonanceChainsConfig?.SequenceNode6IRemainWhoIamEternalMyFlame;

      // Apply SequenceNode1 effects if enabled
      if (sequenceNode1?.isEnabled) {
        // Add CritDMG modifier if not already present
        const hasCritDMG = modifiers.some(
          (mod: any) => mod.modifier === "CritDMG",
        );
        if (!hasCritDMG) {
          modifiers.push({
            modifier: "CritDMG",
            modifySpecificTalents: [
              "BasicAttackSeraphicExecutionStage1DMG",
              "BasicAttackSeraphicExecutionStage2DMG",
              "BasicAttackSeraphicExecutionStage3DMG",
              "BasicAttackSeraphicExecutionStage4DMG",
              "BasicAttackSeraphicExecutionStage5DMG",
              "HeavyAttackFlamewingVerdictStage1DMG",
              "HeavyAttackFlamewingVerdictStage2DMG",
              "HeavyAttackFlamewingVerdictStage3DMG",
              "MidairAttackHellsentBarragePlungingAttackDMG",
              "MidairAttackHellsentBarrageSustainedFireDMG",
              "ResonanceSkillRavageDMG",
              "DodgeCounterPurgatoryScourgeDMG",
            ],
            modifierValue: 0.02,
          });
        }
      }

      // Apply sequenceNode6 effects if enabled
      if (sequenceNode6?.isEnabled) {
        // Add CritDMG modifier if not already present
        const DMGDeepen = modifiers.some(
          (mod: any) => mod.modifier === "DMGDeepen",
        );
        if (!DMGDeepen) {
          modifiers.push({
            modifier: "DMGDeepen",
            modifySpecificTalents: [
              "BasicAttackSeraphicExecutionStage1DMG",
              "BasicAttackSeraphicExecutionStage2DMG",
              "BasicAttackSeraphicExecutionStage3DMG",
              "BasicAttackSeraphicExecutionStage4DMG",
              "BasicAttackSeraphicExecutionStage5DMG",
              "HeavyAttackFlamewingVerdictStage1DMG",
              "HeavyAttackFlamewingVerdictStage2DMG",
              "HeavyAttackFlamewingVerdictStage3DMG",
              "MidairAttackHellsentBarragePlungingAttackDMG",
              "MidairAttackHellsentBarrageSustainedFireDMG",
              "ResonanceSkillRavageDMG",
              "DodgeCounterPurgatoryScourgeDMG",
            ],
            modifierValue: 0.00875,
          });
        }
      }
    }

    // this only applies to BurningDrive on Galbrena
    if (character === "Galbrena" && key === "BurningDrive") {
      const sequenceNode2 =
        resonanceChainsConfig?.SequenceNode2HellboundDiveofFireandAbyss;

      // Apply SequenceNode1 effects if enabled
      if (sequenceNode2?.isEnabled) {
        // Add CritDMG modifier if not already present
        const hasAtk = modifiers.some((mod: any) => mod.modifier === "ATK");
        // it should replace the existing buff, so we check if it does exist
        if (hasAtk) {
          modifiers.push({
            modifier: "ATK",
            // .7 from res chain + 0.2 from original buff
            // wording says 350%, but it's a multiplier against 20%, so 20%*350%
            // not additive
            modifierValue: 0.7,
          });
        }
      }
    }

    // this only applies to BamboosShade on Qiuyuan
    if (character === "Qiuyuan" && key === "BamboosShade") {
      const sequenceNode2 =
        resonanceChainsConfig?.SequenceNode2OBladeIWhoTeachNoMore;

      // Apply SequenceNode2 effects if enabled
      if (sequenceNode2?.isEnabled) {
        const hasEchoAmplify = modifiers.some(
          (mod: any) => mod.modifier === "DMGDeepen:Echo",
        );
        if (!hasEchoAmplify) {
          modifiers.push({
            modifier: "DMGDeepen:Echo",
            modifierValue: 0.3,
          });
        }
      }
    }
    // Buling SequenceNode6AlmightyForumLordofThunderSpell replaces ThunderSpellHeavenEarthMind
    if (character === "Buling" && key === "ThunderSpellHeavenEarthMind") {
      if (
        resonanceChainsConfig?.SequenceNode6AlmightyForumLordofThunderSpell
          ?.isEnabled
      ) {
        // overwrite the modifiers
        modifiers = [
          {
            modifier: "ResonanceSkillDMGBonus",
            modifierValue: 0.5,
          },
        ];
      }
    }
    /**
     * Aemeath: if s2 is enabled, we can just overwrite the existing modifiers
     */
    if (character === "Aemeath" && key === "StardustResonance") {
      if (
        resonanceChainsConfig?.SequenceNode2DownyNotesofSnowfluffFusionBurst
          ?.isEnabled
      ) {
        // overwrite the modifiers
        modifiers = [
          {
            modifier: "talentModifierMultiply",
            modifySpecificTalents: ["ElementalEffectFusionBurst"],
            modifierValue: 4,
          },
        ];
      }
    }
    /**
     * Aemeath: if s2 is enabled, we can just overwrite the existing modifiers
     */
    if (character === "Aemeath" && key === "SeraphicDuetFusionBurst") {
      if (
        resonanceChainsConfig?.SequenceNode2DownyNotesofSnowfluffFusionBurst
          ?.isEnabled
      ) {
        // overwrite the modifiers
        modifiers = [
          {
            modifier: "talentModifierMultiply",
            modifySpecificTalents: ["ElementalEffectFusionBurst"],
            modifierValue: 0.15,
          },
        ];
      }
    }
    /**
     * Aemeath: if s3 is enabled, we can just overwrite the existing modifiers
     * her s3 removes the need for stacks to get the max buffs
     */
    if (character === "Aemeath" && key === "InherentSkillBetweentheStarsTuneRupture") {
      if (
        resonanceChainsConfig?.SequenceNode3FervorSightlyBurnsBrightasNew
          ?.isEnabled
      ) {
        // need to turn off hasStacks, will not affect things upstream, we've copied the buff data
        buff.hasStacks = false;
        // overwrite the modifiers
        modifiers = [
          {
            modifier: "CritDMG",
            modifierValue: 0.6,
          },
          {
            modifier: "DMGDeepen",
            modifySpecificTalents: ["HeavenfallEdictFinaleDMG"],
            modifierValue: 0.25,
          },
        ];
      }
    }
    if (character === "Aemeath" && key === "InherentSkillBetweentheStarsFusionBurst") {
      if (
        resonanceChainsConfig?.SequenceNode3FervorSightlyBurnsBrightasNew
          ?.isEnabled
      ) {
        // need to turn off hasStacks, will not affect things upstream, we've copied the buff data
        buff.hasStacks = false;
        // overwrite the modifiers
        modifiers = [
          {
            modifier: "CritDMG",
            modifierValue: 0.6,
          },
          {
            modifier: "DMGDeepen",
            modifySpecificTalents: ["HeavenfallEdictFinaleDMG"],
            modifierValue: 0.25,
          },
        ];
      }
    }
    if (character === "LuukHerssen" && key === "InherentSkillUncausedDiagnosis") {
      if (
        resonanceChainsConfig?.SequenceNode2AvalancheRoaringinEyes
          ?.isEnabled
      ) {
        modifiers = [
          {
            modifier: "DMGDeepen",
            modifierValue: 0.1,
          },
        ];
      }
    }
    if (character === "LuukHerssen" && key === "EndnotesontheEndgame") {
      if (
        resonanceChainsConfig?.SequenceNode6DawnUnfurlingoverFrostlands
          ?.isEnabled
      ) {
        modifiers = [
          {
            modifier: "talentModifierMultiply",
            modifySpecificTalents: ["RewritteninWintersMargins"],
            modifierValue: 0.25,
          },
          {
            modifySpecificTalents: ["RewritteninWintersMargins"],
            modifierValue: 0.4,
          },
        ];
      }
    }
    if (character === "Rebecca" && key === "SwitchGearsHuntress") {
      if (
        resonanceChainsConfig?.SequenceNode4GotYaCovered
          ?.isEnabled
      ) {
        modifiers = [
          {
            modifier: "CritDMG",
            modifierValue: 0.48,
          },
        ];
      }
    }
    if (character === "Rebecca" && key === "SwitchGearsGuts") {
      if (
        resonanceChainsConfig?.SequenceNode4GotYaCovered
          ?.isEnabled
      ) {
        modifiers = [
          {
            modifier: "DEFIgnore",
            modifierValue: 0.24,
          },
        ];
      }
    }
    if (character === "YangyangXuanling" && key === "InherentSkillUnbrokenVow") {
      const havocBaneStacks = enemy.havocBaneStacks ?? 0;
      if (havocBaneStacks >= 1) {
        const tier1Stacks = Math.min(havocBaneStacks, 3);
        const tier2Stacks = Math.max(0, Math.min(havocBaneStacks - 3, 3));
        const dmgDeepen = Math.min(
          tier1Stacks * 0.1 + tier2Stacks * 0.12,
          0.66,
        );
        modifiers = [
          {
            modifier: "DMGDeepen",
            modifierValue: dmgDeepen,
          },
        ];
      }
    }
    if (character === "Sigrika" && key === "InnateGift") {
      if (
        resonanceChainsConfig?.SequenceNode6TrueNamesResurfacedRisinginLight
          ?.isEnabled
      ) {
        modifiers = [
          {
            modifier: "DMGDeepen",
            modifySpecificTalents: [
              "RunicOutburstDMG",
              "RunicChainWhipDMG",
              "RunicSoliskinDMG",
              "ForteCircuitLearnMyTrueNameDMG",
            ],
            modifierValue: .45, // .3 from base + another .15 from s6
          },
          {
            modifier: "DEFIgnore",
            modifySpecificTalents: [
              "RunicOutburstDMG",
              "RunicChainWhipDMG",
              "RunicSoliskinDMG",
              "ForteCircuitLearnMyTrueNameDMG",
            ],
            modifierValue: 0.075,
          },
        ];
      }
    }
    if (buff.hasStacks) {
      if (buffData?.stacks <= 0) {
        continue;
      }
      let stacks = buffData?.stacks ?? 0;
      // if the buff wants a number of stacks, but the buff has appliesOnEveryStep
      // so it applies the buff in the modifier every N step, so we'll just update the "stacks"
      // based on the number already against this appliesOnEveryStep (int)
      if (buff?.appliesOnEveryStep) {
        stacks = Math.floor((buffData?.stacks ?? 0) / buff?.appliesOnEveryStep);
      }
      if (stacks <= 0) {
        continue;
      }
      modifiers.forEach((modifierItem: any) => {
        if (modifierItem?.modifySpecificTalents) {
          // update modifier value with the value * stacks
          modifierItem.modifierValueCalculated =
            modifierItem.modifierValue * stacks;
          modifySpecificTalents.push(modifierItem);
        } else if (modifierItem.modifier === "Talent") {
          const talentRef =
            talentData?.[modifierItem.modifierValueTalentRef] ?? "10";
          const talentVal = modifierItem.modifierValue[talentRef];
          const target: string =
            modifierItem.modifierTalentTarget ?? "talentModifierMultiplyAdd";
          if (target === "talentModifierMultiply") {
            data.specificTalentBuffs[
              `${modifierItem.modifierTalentKey}:talentModifierMultiply`
            ] =
              (data.specificTalentBuffs[
                `${modifierItem.modifierTalentKey}:talentModifierMultiply`
              ] || 0) +
              talentVal * stacks;
          } else {
            data[`${modifierItem.modifierTalentKey}:talentModifierMultiplyAdd`] =
              talentVal * stacks;
          }
        } else if (modifierItem.modifier === "EnableAttack") {
          data.EnableAttack.push(...modifierItem.modifierValue);
        } else {
          const totalValue = modifierItem.modifierValue * stacks;
          data[modifierItem.modifier] =
            (data[modifierItem.modifier] || 0) + totalValue;
        }
      });
    } else {
      modifiers.forEach((modifierItem: any) => {
        if (modifierItem?.modifySpecificTalents) {
          // add our calculated value
          modifierItem.modifierValueCalculated = modifierItem.modifierValue;
          modifySpecificTalents.push(modifierItem);
        } else if (modifierItem.modifier === "Talent") {
          // this is the rare case where the modifier value needs a reference to another talent level
          // specifically Jinhsi incandescence buff scales off of her forte talent
          const talentRef =
            talentData?.[modifierItem.modifierValueTalentRef] ?? "10";
          const talentVal = modifierItem.modifierValue[talentRef];
          const target: string =
            modifierItem.modifierTalentTarget ?? "talentModifierMultiplyAdd";
          if (target === "talentModifierMultiply") {
            data.specificTalentBuffs[
              `${modifierItem.modifierTalentKey}:talentModifierMultiply`
            ] =
              (data.specificTalentBuffs[
                `${modifierItem.modifierTalentKey}:talentModifierMultiply`
              ] || 0) + talentVal;
          } else {
            data[`${modifierItem.modifierTalentKey}:talentModifierMultiplyAdd`] =
              talentVal;
          }
        } else if (modifierItem.modifier === "talentModifierMultiply") {
          // for buffs that apply talentModifierMultiply to the calcs
          if (!data.talentModifierMultiply) {
            data.talentModifierMultiply = [];
          }
          data.talentModifierMultiply.push(modifierItem);
        } else if (modifierItem.modifier === "EnableAttack") {
          data.EnableAttack.push(...modifierItem.modifierValue);
        } else {
          data[modifierItem.modifier] =
            (data[modifierItem.modifier] || 0) + modifierItem.modifierValue;
        }
      });
    }

    /**
     * Aemeath:
     * Note doing it here as these modifiers should NOT be affected by stacks
     * if InherentSkillBetweentheStarsTuneRupture -> has 3 stacks = add Resonance Liberation Heavenfall Edict: Finale DMG is Amplified by 25%.
     * if InherentSkillBetweentheStarsFusionBurst -> has 2 stacks = add Resonance Liberation Heavenfall Edict: Finale DMG is Amplified by 25%.
     * (same buff)
     * This will get bypassed if her s3 is enabled and that's handled above
     */
    if (character === "Aemeath" && key === "InherentSkillBetweentheStarsTuneRupture") {
      if (!resonanceChainsConfig?.SequenceNode3FervorSightlyBurnsBrightasNew?.isEnabled) {
        if (buffData?.stacks >= 3) {
          data.specificTalentBuffs["HeavenfallEdictFinaleDMG:DMGDeepen"] = 0.25;
        }
      }
    }
    if (character === "Qingxiao" && key === "Mindlock") {
      // For each stack of Mindlock on the target, DMG taken by the target from the following Qingxiao skills is Amplified by 2%. This effect increases by 5% per stack for the first 7 stacks. - Heavy Attack - Stringblade, Basic Attack - Ephemeral Transcendence, Dodge Counter - Ephemeral Transcendence, Heavy Attack - Heaven's Reckoning: Ephemeral Transcendence, Resonance Skill - Billows Beneath Heaven.
      const mindlockStacks = buffData?.stacks ?? 0;

      let mindlockAmplifyPercent = 0;
      if (mindlockStacks > 0) {
        if (mindlockStacks <= 7) {
          mindlockAmplifyPercent = 7 * mindlockStacks;
        } else {
          mindlockAmplifyPercent = (7*7) + 2 * (mindlockStacks - 7);
        }
      }

      const dmgMultiplier = mindlockAmplifyPercent / 100;

      data.specificTalentBuffs["HeavyAttackStringbladeDMG:DMGDeepen"] = dmgMultiplier;
      data.specificTalentBuffs["BasicAttackEphemeralTranscendenceStage1DMG:DMGDeepen"] = dmgMultiplier;
      data.specificTalentBuffs["BasicAttackEphemeralTranscendenceStage2DMG:DMGDeepen"] = dmgMultiplier;
      data.specificTalentBuffs["BasicAttackEphemeralTranscendenceStage3DMG:DMGDeepen"] = dmgMultiplier;
      data.specificTalentBuffs["BasicAttackEphemeralTranscendenceStage4DMG:DMGDeepen"] = dmgMultiplier;
      data.specificTalentBuffs["DodgeCounterEphemeralTranscendenceDMG:DMGDeepen"] = dmgMultiplier;
      data.specificTalentBuffs["HeavenSReckoningEphemeralTranscendenceDMG:DMGDeepen"] = dmgMultiplier;
      data.specificTalentBuffs["BillowsBeneathHeavenDMG:DMGDeepen"] = dmgMultiplier;

      // if InherentSkillToKnowToBanish selfbuff is enabled, add DmgBonus to the same attacks with the same amount
      if (buffsConfig?.InherentSkillToKnowToBanish?.isEnabled) {
        data.specificTalentBuffs["HeavyAttackStringbladeDMG:Aero"] = dmgMultiplier;
        data.specificTalentBuffs["BasicAttackEphemeralTranscendenceStage1DMG:Aero"] = dmgMultiplier;
        data.specificTalentBuffs["BasicAttackEphemeralTranscendenceStage2DMG:Aero"] = dmgMultiplier;
        data.specificTalentBuffs["BasicAttackEphemeralTranscendenceStage3DMG:Aero"] = dmgMultiplier;
        data.specificTalentBuffs["BasicAttackEphemeralTranscendenceStage4DMG:Aero"] = dmgMultiplier;
        data.specificTalentBuffs["DodgeCounterEphemeralTranscendenceDMG:Aero"] = dmgMultiplier;
        data.specificTalentBuffs["HeavenSReckoningEphemeralTranscendenceDMG:Aero"] = dmgMultiplier;
        data.specificTalentBuffs["BillowsBeneathHeavenDMG:Aero"] = dmgMultiplier;
      }
      // if SequenceNode3DreamsFadeSwordAbides, buff HeavenSReckoningEphemeralTranscendenceDMG * 0.03 for every stack of Mindlock
      // it multiplies against the 100% buff from Heaven's Clarity
      if (resonanceChainsConfig?.SequenceNode3DreamsFadeSwordAbides?.isEnabled) {
        data.specificTalentBuffs["HeavenSReckoningEphemeralTranscendenceDMG:talentModifierSpecialMultiply"] = 0.03 * mindlockStacks;
      }
      // if SequenceNode6CleanseThisTarnishedAgeTillAllRunsClear, buff Juque Perdition taken by the target is Amplified by 2%. The first 7 stacks additionally grant 5% DMG Amplification
      // When Inherent Skill - To Know, To Banish is unlocked, the DMG of Juque Perdition on targets with Mindlock is increased by 2% for each stack of Mindlock. The first 7 stacks additionally grant 5% DMG increase.
      if (resonanceChainsConfig?.SequenceNode6CleanseThisTarnishedAgeTillAllRunsClear?.isEnabled) {
        data.specificTalentBuffs["SequenceNode1LikeCloudsThatMeetAndDriftApart:DMGDeepen"] = dmgMultiplier;
        data.specificTalentBuffs["SequenceNode1LikeCloudsThatMeetAndDriftApart:Aero"] = dmgMultiplier;
      }
    }
    if (character === "Aemeath" && key === "InherentSkillBetweentheStarsFusionBurst") {
      if (!resonanceChainsConfig?.SequenceNode3FervorSightlyBurnsBrightasNew?.isEnabled) {
        if (buffData?.stacks >= 2) {
          data.specificTalentBuffs["HeavenfallEdictFinaleDMG:DMGDeepen"] = 0.25;
        }
      }
    }
    if (character === "Sigrika" && key === "InherentSkillTrueNamesAligned") {
      if (buffData?.stacks >= 6) {
        data["Aero"] += 0.3;
        data["EchoDMGBonus"] += 0.3;
      }
    }
    if (character === "Lucy" && key === "InherentSkillFunctionCracking") {
      if (buffData?.stacks >= 2) {
        data["DMGDeepen"] += 0.05;
        // add the extra 5%
        data.specificTalentBuffs["HackResponseDataCrashDMG:talentModifierMultiply"] = 0.05;
        data.specificTalentBuffs["SpoofingProgramCrippleMovementDMG:talentModifierMultiply"] = 0.05;
      }
    }
    if (character === "Hiyuki" && key === "InherentSkillFineSnow") {
      if (buffData?.stacks >= 1) {
        data["DMGDeepen:GlacioChafe"] = (data["DMGDeepen:GlacioChafe"] || 0) + 0.3;
        data["CritDMG"] = (data["CritDMG"] || 0) + 0.4;
      }
      if (buffData?.stacks >= 2) {
        data["EnableAttack"].push("InherentSkillFineSnow");
      }
      if (buffData?.stacks >= 3) {
        data["DMGDeepen:GlacioChafe"] = (data["DMGDeepen:GlacioChafe"] || 0) + 0.3;
      }
      // SequenceNode6IntoaNightWithoutEnd
      if (resonanceChainsConfig?.SequenceNode6IntoaNightWithoutEnd?.isEnabled) {
        if (buffData?.stacks >= 2) {
          data["CritDMG"] = (data["CritDMG"] || 0) + 0.4;
        }
        if (buffData?.stacks >= 3) {
          data.specificTalentBuffs["GlacioBiteDMG:specialMultiplier"] = 0.25;
          data.specificTalentBuffs["ElementalEffectGlacioBite:talentModifierMultiply"] = 0.25;
        }
      }
    }
    // Unison Boon's own stack count also drives per-stack bonuses on two
    // Sequence Node 1/3 Unison-branch modifiers, on top of their flat
    // resonance-chain modifiers declared normally.
    if (character === "Hsin" && key === "UnisonBoon") {
      const unisonBoonStacks = buffData?.stacks ?? 0;
      if (unisonBoonStacks > 0 && activeStance === "Unison") {
        if (
          resonanceChainsConfig?.SequenceNode1ABoatToCrossTheRisingTideUnison
            ?.isEnabled
        ) {
          [
            "IntroSkillAnsweringFormManifoldUnisonDMG",
            "IntroSkillIlluminingFormManifoldUnisonDMG",
          ].forEach((talentKey) => {
            data.specificTalentBuffs[`${talentKey}:talentModifierMultiply`] =
              (data.specificTalentBuffs[`${talentKey}:talentModifierMultiply`] ||
                0) +
              unisonBoonStacks * 0.1;
          });
        }
        if (
          resonanceChainsConfig?.SequenceNode3ADreamOfReturnAmongTheHillsUnison
            ?.isEnabled
        ) {
          data.specificTalentBuffs["PillarsAcrossHeavenDMG:CritDMG"] =
            (data.specificTalentBuffs["PillarsAcrossHeavenDMG:CritDMG"] || 0) +
            unisonBoonStacks * 0.15;
        }
      }
    }
    // Suoming Sequence Node 6: Nine Shadows at Her Side increases the effect
    // of each Unison Boon stack by 50% (3% -> 4.5% Total DMG per stack).
    if (character === "Suoming" && key === "UnisonBoon") {
      const unisonBoonStacks = buffData?.stacks ?? 0;
      if (
        unisonBoonStacks > 0 &&
        resonanceChainsConfig?.SequenceNode6NineShadowsAtHerSide?.isEnabled
      ) {
        data["TotalDamage"] =
          (data["TotalDamage"] || 0) + unisonBoonStacks * 0.015;
      }
    }
    // Suoming Sequence Node 6: Nine Shadows at Her Side further increases
    // Crit. DMG by 80% while Seal Master (from Inherent Skill: Sunken Seal,
    // Forged Lock) is active.
    if (character === "Suoming" && key === "InherentSkillSunkenSealForgedLock") {
      if (resonanceChainsConfig?.SequenceNode6NineShadowsAtHerSide?.isEnabled) {
        data["CritDMG"] = (data["CritDMG"] || 0) + 0.8;
      }
    }
    if (character === "Denia" && key === "InherentSkillEtchedColorsOffTuneBuildupRate") {
      if (buffData?.stacks >= 1) {
        const tuneBreakBoost = computeDeniaOffTuneBuildupTuneBreakBoost(
          buffData?.stacks ?? 0,
        );
        if (tuneBreakBoost > 0) {
          data["tuneBreakBoost"] = (data["tuneBreakBoost"] || 0) + tuneBreakBoost;
        }
      }
    }
    if (character === "Denia" && key === "DarkCore") {
      // SequenceNode3ThroughDarkandWindtheErlkingFollows
      const sequenceNode3Config =
        resonanceChainsConfig?.SequenceNode3ThroughDarkandWindtheErlkingFollows;
      if (sequenceNode3Config?.isEnabled) {
        const darkCoreBuffTargets = getResonanceChainBuffAttackTargets(
          sequenceNode3Config,
          [
            "PhantomBubbleStagecraftFormDMG",
            "BasicAttackStagecraftFormStage4DMG",
          ],
          "darkCoreConsumeBuffTarget",
        );
        darkCoreBuffTargets.forEach((talentKey: string) => {
          if (buffData?.stacks >= 5) {
            data.specificTalentBuffs[`${talentKey}:talentModifierMultiply`] = 12;
          }
          data.specificTalentBuffs[`${talentKey}:talentTypeOverride`] =
            "Liberation";
        });
      }
    }
  }
  // this needs to go last, otherwise it will run every time a buff is set and way over-buff by applying itself too many times
  modifySpecificTalents.forEach((item: any) => {
    const talents = item?.modifySpecificTalents ?? [];
    const { modifier, modifierValue, modifierValueCalculated } = item;
    talents.forEach((talent: string) => {
      let modifierStr = "";
      // not everything will have a modifier, so append the : and modifier if we have it
      if (modifier) {
        modifierStr = `:${modifier}`;
      }
      if (modifier === "talentTypeOverride") {
        data.specificTalentBuffs[`${talent}${modifierStr}`] = (modifierValueCalculated || modifierValue);
      } else {
        data.specificTalentBuffs[`${talent}${modifierStr}`] = 
          (data.specificTalentBuffs[`${talent}${modifierStr}`] || 0) +
          (modifierValueCalculated || modifierValue);
      }
    });
  });
  // final adjustments where needed before surfacing this up

  if (character === "Lupa" && data.specificTalentBuffs) {
    if (
      resonanceChainsConfig?.SequenceNode6TotheBrightestFlamingStar?.isEnabled
    ) {
      // copy the same buffs for NowheretoRunDMG from the other intro
      const atk = data.specificTalentBuffs?.[`TryFocusingEhDMG:ATK`];
      const fusion = data?.specificTalentBuffs?.[`TryFocusingEhDMG:Fusion`];
      const resistIgnore =
        data?.specificTalentBuffs?.[`TryFocusingEhDMG:ResistIgnore:Fusion`];
      data.specificTalentBuffs["NowheretoRunDMG:ATK"] = atk || 0;
      data.specificTalentBuffs["NowheretoRunDMG:Fusion"] = fusion || 0;
      data.specificTalentBuffs["NowheretoRunDMG:ResistIgnore:Fusion"] =
        resistIgnore || 0;
    }
  }
  if (character === "Lucy" && data.specificTalentBuffs) {
    if (
      resonanceChainsConfig?.SequenceNode2TheBlackwallthePasttheEscape?.isEnabled
    ) {
      data.specificTalentBuffs["HeavyAttackMultithreadingDMG:talentModifierMultiply"] = 5.6;
    }
  }
  return data;
};

// Separate function to calculate ONLY AdditionalBase modifiers
// These modifiers depend on final stats (like CritRate), so they need to be calculated
// after resonance chains and self buffs have been applied
type AdditionalBasePassive = {
  hasStacks?: boolean;
  stacks?: number;
  modifiers: any[];
};

const applyAdditionalBaseModifiers = (
  modifiers: any[],
  hasStacks: boolean,
  stacks: number,
  energyRegen: number,
  critRate: number,
  data: Record<string, any>,
  maxHp: number = 0,
  talentData: Record<string, any> | null = null,
) => {
  modifiers.forEach((modifierItem: any) => {
    if (!modifierItem?.modifier?.includes("AdditionalBase")) {
      return;
    }
    let base = 0;
    let currentAmount = 0;
    // HP is a raw stat value (e.g. 30000), not a percentage like EnergyRegen/CritRate,
    // so it isn't scaled by 100 the way those are below.
    let scale = 100;
    switch (modifierItem.modifierBasedOn) {
      case "EnergyRegen":
        base = modifierItem?.minStatValue ?? 0;
        currentAmount = energyRegen;
        break;
      case "CritRate":
        base = modifierItem?.minStatValue ?? 0.05;
        currentAmount = critRate;
        break;
      case "HP":
        base = modifierItem?.minStatValue ?? 0;
        currentAmount = maxHp;
        scale = 1;
        break;
      default:
        base = modifierItem?.minStatValue ?? 0;
        break;
    }
    const additionalAmount = currentAmount * scale - base * scale;
    let steps = Math.floor(additionalAmount / modifierItem.modifierStep);
    // caps how many steps count toward the effect (e.g. "up to 25000 HP over the
    // threshold counts"), independent of any maximumValue cap on the final buffValue
    if (modifierItem.maxSteps !== undefined && steps > modifierItem.maxSteps) {
      steps = modifierItem.maxSteps;
    }
    // modifierValue can be a flat number, or (for buffs like Jinhsi's Incandescence
    // pattern) a map of forte level -> value, resolved via modifierValueTalentRef
    let resolvedModifierValue = modifierItem.modifierValue;
    if (
      resolvedModifierValue !== null &&
      typeof resolvedModifierValue === "object"
    ) {
      const talentRef =
        talentData?.[modifierItem.modifierValueTalentRef ?? "forte"] ?? "10";
      resolvedModifierValue = resolvedModifierValue[talentRef] ?? 0;
    }
    let perOccurrenceValue = steps * resolvedModifierValue;
    // for hasStacks buffs where each stack independently caps (e.g. "up to 2.5% per
    // stack"), cap the per-stack value before multiplying by the stack count, since
    // capping only the total afterwards would under-cap partial stack counts
    if (
      modifierItem.perStackMaximumValue !== undefined &&
      perOccurrenceValue > modifierItem.perStackMaximumValue
    ) {
      perOccurrenceValue = modifierItem.perStackMaximumValue;
    }
    let buffValue = perOccurrenceValue * (hasStacks ? stacks : 1);
    if (buffValue > modifierItem.maximumValue) {
      buffValue = modifierItem.maximumValue;
    }
    if (buffValue < 0) {
      buffValue = 0;
    }
    const modifiesSpecificTalents = modifierItem?.modifySpecificTalents ?? [];
    if (modifiesSpecificTalents.length <= 0) {
      switch (modifierItem.modifierTargetAttr) {
        case "CritRate":
          data["CritRate"] = (data["CritRate"] || 0) + buffValue;
          break;
        case "CritDMG":
          data["CritDMG"] = (data["CritDMG"] || 0) + buffValue;
          break;
        case "ATK":
          data["ATK"] = (data["ATK"] || 0) + buffValue;
          break;
        case "ATK_FLAT":
          data["ATK_FLAT"] = (data["ATK_FLAT"] || 0) + buffValue;
          break;
        case "DMGBonus":
          data["DMGBonus"] = (data["DMGBonus"] || 0) + buffValue;
          break;
        case "EchoDMGBonus":
          data["EchoDMGBonus"] = (data["EchoDMGBonus"] || 0) + buffValue;
          break;
        default:
          // generic passthrough (e.g. elemental bonuses like "Fusion", or "HealingBonus")
          data[modifierItem.modifierTargetAttr] =
            (data[modifierItem.modifierTargetAttr] || 0) + buffValue;
          break;
      }
    } else {
      const specificTalentBuffs: Record<string, number> = {};
      modifierItem.modifySpecificTalents.forEach((talent: string) => {
        const talentModifierKey = `${talent}:${modifierItem.modifierTargetAttr}`;
        specificTalentBuffs[talentModifierKey] =
          (specificTalentBuffs[talentModifierKey] || 0) + buffValue;
      });
      data.specificTalentBuffs = Object.assign(
        {},
        data.specificTalentBuffs,
        specificTalentBuffs,
      );
    }
  });
};

export const computeAdditionalBaseFromPassives = (
  passives: AdditionalBasePassive[] = [],
  energyRegen: number = 0,
  critRate: number = 0,
  maxHp: number = 0,
  talentData: Record<string, any> | null = null,
): Record<string, any> => {
  const data: Record<string, any> = {};
  for (const passive of passives) {
    if (passive.hasStacks && (passive.stacks ?? 0) <= 0) {
      continue;
    }
    applyAdditionalBaseModifiers(
      passive.modifiers ?? [],
      Boolean(passive.hasStacks),
      passive.stacks ?? 0,
      energyRegen,
      critRate,
      data,
      maxHp,
      talentData,
    );
  }
  return data;
};

export const mergeAdditionalBaseData = (
  target: Record<string, any> = {},
  source: Record<string, any> = {},
) => {
  const merged: Record<string, any> = {};
  const keys = new Set([
    ...Object.keys(target ?? {}),
    ...Object.keys(source ?? {}),
  ]);
  keys.delete("specificTalentBuffs");
  for (const key of keys) {
    merged[key] = (target?.[key] || 0) + (source?.[key] || 0);
  }
  merged.specificTalentBuffs = Object.assign(
    {},
    target?.specificTalentBuffs ?? {},
    source?.specificTalentBuffs ?? {},
  );
  return merged;
};

export const computeAdditionalBaseBuffs = (
  buffsConfig: any = null,
  buffsCharInfo: any = null,
  resonanceChainsConfig: any = null,
  character: string = "",
  energyRegen: number = 0,
  critRate: number = 0,
  activeStance: string | null = null,
  maxHp: number = 0,
  talentData: Record<string, any> | null = null,
): any => {
  if (!buffsCharInfo || buffsCharInfo.length <= 0) {
    return {};
  }
  const data: any = {};

  const entries = Object.entries(buffsConfig) as [string, any][];
  for (const [key, buffData] of entries) {
    if (!buffData?.isEnabled) {
      continue;
    }
    const buffFromCharacter = buffsCharInfo.find(
      (buffItem: any) => buffItem.key === key,
    );
    if (!buffFromCharacter) {
      continue;
    }
    if (!isBuffActiveForStance(buffFromCharacter, activeStance)) {
      continue;
    }
    // No clone needed: unlike computeSelfBuffs, applyAdditionalBaseModifiers
    // below only reads from these modifier objects, never mutates them — so
    // referencing the shared character buff definition directly is safe and
    // avoids a JSON round-trip on every enabled buff, for every loadout.
    const buff = buffFromCharacter;
    // on Brant, if this is TheatricalMoment, check if MyMoment, if so, ignore this buff
    if (character === "Brant" && key === "TheatricalMoment") {
      if (buffsConfig?.MyMoment?.isEnabled) {
        continue;
      }
    }

    const modifiersData = buff?.modifiers ?? [];
    let modifiers = modifiersData;

    // Calculate adjusted CritRate that includes non-AdditionalBase modifiers (like SequenceNode2)
    // This is needed because AdditionalBase modifiers depend on the final CritRate including these buffs
    let adjustedCritRate = critRate;
    let adjustedEnergyRegen = energyRegen;

    // Apply character-specific modifications (like Augusta's SequenceNode2 adding CritRate)
    if (character === "Augusta" && key === "CrownofWills") {
      const sequenceNode2 =
        resonanceChainsConfig?.SequenceNode2CleansedinCrimsonWar;

      if (sequenceNode2?.isEnabled) {
        // SequenceNode2 adds 20% CritRate per stack
        const stacks = buff.hasStacks ? (buffData?.stacks ?? 1) : 1;
        adjustedCritRate = critRate + 0.2 * stacks;
      }
    }

    // on Jingran, SequenceNode3 replaces Yang Changes, Yin Unites with the
    // stronger Yin-Yang Everflow (50 ATK per 1000 Max HP, up to 2500, vs the
    // base buff's 36 per 1000 up to 1800) -- that upgraded version is already
    // applied as SequenceNode3's own chain modifier in resonanceChains.ts, so
    // skip the base self-buff here rather than stacking both.
    if (character === "Jingran" && key === "YangChangesYinUnites") {
      const sequenceNode3 =
        resonanceChainsConfig?.SequenceNode3WorldSCourseShiftsEachToTheirRightfulPaths;
      if (sequenceNode3?.isEnabled) {
        continue;
      }
    }

    // Process only AdditionalBase modifiers
    if (buff.hasStacks) {
      if (buffData?.stacks <= 0) {
        continue;
      }
      applyAdditionalBaseModifiers(
        modifiers,
        true,
        buffData?.stacks ?? 0,
        adjustedEnergyRegen,
        adjustedCritRate,
        data,
        maxHp,
        talentData,
      );
    } else {
      applyAdditionalBaseModifiers(
        modifiers,
        false,
        0,
        adjustedEnergyRegen,
        adjustedCritRate,
        data,
        maxHp,
        talentData,
      );
    }
  }
  return data;
};

// Separate function to calculate ONLY CritOverflow modifiers
// These modifiers convert excess CritRate into CritDMG
export const computeCritOverflowBuffs = (
  buffsConfig: any = null,
  buffsCharInfo: any = null,
  resonanceChainsConfig: any = null,
  resonanceChainsCharInfo: any = null,
  critRate: number = 0,
  activeStance: string | null = null,
): any => {
  const data: any = {};

  // Helper function to process CritOverflow modifiers from a buff
  const processCritOverflowModifiers = (
    modifiers: any[],
    hasStacks: boolean,
    stacks: number = 0,
  ) => {
    modifiers.forEach((modifierItem: any) => {
      if (modifierItem.modifier === "CritOverflow") {
        if (critRate > modifierItem.overflowMin) {
          const { modifierValue, overflowStep, overflowMin, overflowMax } =
            modifierItem;
          const overflowAmount = Math.max(0, critRate - overflowMin);
          const overflowSteps = Math.floor(overflowAmount / overflowStep);
          const overflowBonus = Math.min(
            overflowSteps * modifierValue * (hasStacks ? stacks : 1),
            overflowMax,
          );
          data["CritDMG"] = (data["CritDMG"] || 0) + overflowBonus;
        }
      }
    });
  };

  // Check regular buffs
  if (
    buffsConfig &&
    buffsCharInfo &&
    Array.isArray(buffsCharInfo) &&
    buffsCharInfo.length > 0
  ) {
    const entries = Object.entries(buffsConfig) as [string, any][];
    for (const [key, buffData] of entries) {
      if (!buffData?.isEnabled) {
        continue;
      }
      const buffFromCharacter = buffsCharInfo.find(
        (buffItem: any) => buffItem.key === key,
      );
      if (!buffFromCharacter) {
        continue;
      }
      if (!isBuffActiveForStance(buffFromCharacter, activeStance)) {
        continue;
      }
      // processCritOverflowModifiers only reads modifier fields, so — as in
      // computeAdditionalBaseBuffs above — no clone is needed here.
      const buff = buffFromCharacter;

      const modifiersData = buff?.modifiers ?? [];
      const modifiers = modifiersData;

      if (buff.hasStacks) {
        if (buffData?.stacks <= 0) {
          continue;
        }
        processCritOverflowModifiers(modifiers, true, buffData?.stacks ?? 0);
      } else {
        processCritOverflowModifiers(modifiers, false);
      }
    }
  }

  // Check resonance chains
  if (
    resonanceChainsConfig &&
    resonanceChainsCharInfo &&
    Array.isArray(resonanceChainsCharInfo) &&
    resonanceChainsCharInfo.length > 0
  ) {
    const entries = Object.entries(resonanceChainsConfig) as [string, any][];
    for (const [key, chainData] of entries) {
      if (!chainData?.isEnabled) {
        continue;
      }
      const chainFromCharacter = resonanceChainsCharInfo.find(
        (chainItem: any) => chainItem.key === key,
      );
      if (!chainFromCharacter) {
        continue;
      }
      if (!isBuffActiveForStance(chainFromCharacter, activeStance)) {
        continue;
      }
      const chain = chainFromCharacter;

      const modifiersData = chain?.modifiers ?? [];
      const modifiers = modifiersData;

      if (chain.hasStacks) {
        if (chainData?.stacks <= 0) {
          continue;
        }
        processCritOverflowModifiers(modifiers, true, chainData?.stacks ?? 0);
      } else {
        processCritOverflowModifiers(modifiers, false);
      }
    }
  }

  return data;
};

export const computeResonanceChainsBuffs = (
  buffsConfig: any = null,
  buffsCharInfo: any = null,
  talentData: any = {},
  activeStance: string | null = null,
): any => {
  // find the buff in our char data
  if (!buffsCharInfo || buffsCharInfo.length <= 0) {
    return;
  }
  const data: any = {
    EnableAttack: [],
    specificTalentBuffs: {},
  };

  const modifySpecificTalents: any = [];
  // go through each buffsConfig, make sure it's enabled, then compute the buff
  const entries = Object.entries(buffsConfig) as [string, any][];
  for (const [key, buffData] of entries) {
    // skip if it's not enabled
    if (!buffData?.isEnabled) {
      continue;
    }
    const buffFromCharacter = buffsCharInfo.find(
      (buffItem: any) => buffItem.key === key,
    );
    if (!buffFromCharacter) {
      continue;
    }
    if (!isBuffActiveForStance(buffFromCharacter, activeStance)) {
      continue;
    }
    const buff = JSON.parse(JSON.stringify(buffFromCharacter));

    const modifiersData = buff?.modifiers ?? [];
    let modifiers = JSON.parse(JSON.stringify(modifiersData));

    if (buff.hasStacks) {
      if (buffData?.stacks <= 0) {
        continue;
      }
      const stacks = buffData?.stacks ?? 0;
      modifiers.forEach((modifierItem: any) => {
        if (modifierItem?.modifySpecificTalents) {
          // update modifier value with the value * stacks
          modifierItem.modifierValueCalculated =
            modifierItem.modifierValue * stacks;
          modifySpecificTalents.push(modifierItem);
        } else if (modifierItem.modifier === "Talent") {
          const talentRef =
            talentData?.[modifierItem.modifierValueTalentRef] ?? "10";
          const talentVal = modifierItem.modifierValue[talentRef];
          const target: string =
            modifierItem.modifierTalentTarget ?? "talentModifierMultiplyAdd";
          if (target === "talentModifierMultiply") {
            data.specificTalentBuffs[
              `${modifierItem.modifierTalentKey}:talentModifierMultiply`
            ] =
              (data.specificTalentBuffs[
                `${modifierItem.modifierTalentKey}:talentModifierMultiply`
              ] || 0) +
              talentVal * stacks;
          } else {
            data[`${modifierItem.modifierTalentKey}:talentModifierMultiplyAdd`] =
              talentVal * stacks;
          }
        } else if (modifierItem.modifier === "EnableAttack") {
          data.EnableAttack.push(...modifierItem.modifierValue);
        } else if (modifierItem.modifier === "TalentReplace") {
          modifySpecificTalents.push(modifierItem);
        } else {
          const totalValue = modifierItem.modifierValue * stacks;
          data[modifierItem.modifier] =
            (data[modifierItem.modifier] || 0) + totalValue;
        }
      });
    } else {
      modifiers.forEach((modifierItem: any) => {
        if (modifierItem?.modifySpecificTalents) {
          // add our calculated value
          modifierItem.modifierValueCalculated = modifierItem.modifierValue;
          modifySpecificTalents.push(modifierItem);
        } else if (modifierItem.modifier === "Talent") {
          // this is the rare case where the modifier value needs a reference to another talent level
          // specifically Jinhsi incandescence buff scales off of her forte talent
          const talentRef =
            talentData?.[modifierItem.modifierValueTalentRef] ?? "10";
          const talentVal = modifierItem.modifierValue[talentRef];
          const target: string =
            modifierItem.modifierTalentTarget ?? "talentModifierMultiplyAdd";
          if (target === "talentModifierMultiply") {
            data.specificTalentBuffs[
              `${modifierItem.modifierTalentKey}:talentModifierMultiply`
            ] =
              (data.specificTalentBuffs[
                `${modifierItem.modifierTalentKey}:talentModifierMultiply`
              ] || 0) + talentVal;
          } else {
            data[`${modifierItem.modifierTalentKey}:talentModifierMultiplyAdd`] =
              talentVal;
          }
        } else if (modifierItem.modifier === "talentModifierMultiply") {
          // for buffs that apply talentModifierMultiply to the calcs
          if (!data.talentModifierMultiply) {
            data.talentModifierMultiply = [];
          }
          data.talentModifierMultiply.push(modifierItem);
        } else if (modifierItem.modifier === "EnableAttack") {
          data.EnableAttack.push(...modifierItem.modifierValue);
        } else {
          data[modifierItem.modifier] =
            (data[modifierItem.modifier] || 0) + modifierItem.modifierValue;
        }
      });
    }
  }
  modifySpecificTalents.forEach((item: any) => {
    const talents = item?.modifySpecificTalents ?? [];
    const { modifier, modifierValue, modifierValueCalculated } = item;
    talents.forEach((talent: string) => {
      if (modifier === "talentReplace") {
        data.specificTalentBuffs[`${talent}:${modifier}`] = modifierValue;
      } else {
        let modifierStr = "";
        // not everything will have a modifier, so append the : and modifier if we have it
        if (modifier) {
          modifierStr = `:${modifier}`;
        }
        data.specificTalentBuffs[`${talent}${modifierStr}`] =
          (data.specificTalentBuffs[`${talent}${modifierStr}`] || 0) +
          (modifierValueCalculated || modifierValue);
      }
    });
  });
  return data;
};

export const applyCharacterStatEdgeCases = (
  stats: any,
  character: string = "",
  resonanceChainsConfig: any = null,
): void => {
  if (
    character === "Rebecca" &&
    resonanceChainsConfig?.SequenceNode6MaybeJustMaybe?.isEnabled
  ) {
    stats.basicAttackDMGBonus *= 1.4;
  }
};

// Pure function to calculate all stats with full context
// This function is designed to work in web workers - no Vue dependencies, all state passed as parameters
// Returns both final stats and breakdown data for UI
/**
 * Steps 3-7 of `calculateAllStats`: everything from the intermediate
 * `calcCharStats` pass through `applyCharacterStatEdgeCases`, given
 * already-resolved `selfBuffsData`/`resonanceChainsBuffsData` instead of
 * deriving them from raw config. Split out so callers that need to score the
 * same base config across many echo loadouts (the Optimizer's per-loadout hot
 * path) can compute `selfBuffsData`/`resonanceChainsBuffsData` once and reuse
 * this for every loadout, instead of re-deriving them — via
 * `computeSelfBuffs`/`computeResonanceChainsBuffs`, both pure functions of
 * buff config, unrelated to echoes — on every call like `calculateAllStats`
 * does. `calculateAllStats` itself is just this plus steps 1-2.
 */
export const calculateFinalStatsFromBuffs = (context: {
  // Character base stats
  baseHp: number;
  baseAtk: number;
  baseDef: number;

  // Weapon data
  weaponAtk: number;
  weaponModifier: string | null;
  weaponModifierValue: number;
  weaponPassiveData: any;

  // Buff configurations (enabled state)
  buffsConfig: any;
  resonanceChainsConfig: any;
  customBuffs: any;
  teamBuffsData: any;
  echoStats: any;

  // Character data (definitions)
  buffsCharInfo: any[];
  resonanceChainsCharInfo: any[];

  // Character metadata
  character: string;
  talentData: any;
  activeStance?: string | null;

  // Options
  ignoreBuffs?: {
    ignoreTeamBuffs?: boolean;
    ignoreWeaponBuffs?: boolean;
    ignoreEchoes?: boolean;
  };

  // Echo set passives with AdditionalBase modifiers
  setBonusLabels?: (string | null | undefined)[];
  echoSetPassivesConfig?: Record<
    string,
    { isEnabled?: boolean; stacks?: number }
  >;

  // Already-resolved by the caller (steps 1-2 of calculateAllStats)
  selfBuffsData: any;
  resonanceChainsBuffsData: any;

  // Bypasses the `ignoreEchoes` gate that the `echoStats` field above is
  // subject to — used by the Optimizer's per-loadout scoring, which sets
  // `ignoreBuffs.ignoreEchoes: true` to suppress `echoStats` but still needs
  // the loadout's own combined echo stats applied unconditionally.
  injectEchoStats?: any;
}): {
  finalStats: any;
  selfBuffsData: any;
  resonanceChainsBuffsData: any;
  additionalBaseBuffsData: any;
  critOverflowBuffsData: any;
  echoSetAdditionalBaseBuffsData: any;
} => {
  const {
    baseHp,
    baseAtk,
    baseDef,
    weaponAtk,
    weaponModifier,
    weaponModifierValue,
    weaponPassiveData,
    buffsConfig,
    resonanceChainsConfig,
    customBuffs,
    teamBuffsData,
    echoStats,
    buffsCharInfo,
    resonanceChainsCharInfo,
    character,
    talentData,
    activeStance = null,
    ignoreBuffs = {},
    setBonusLabels = [],
    echoSetPassivesConfig = {},
    selfBuffsData,
    resonanceChainsBuffsData,
    injectEchoStats = null,
  } = context;

  // Step 3: Calculate intermediate stats with resonance chains and self buffs
  // This internally calculates base stats, then applies resonance chains and self buffs
  const intermediateStats = calcCharStats(
    "All",
    null,
    ignoreBuffs,
    injectEchoStats,
    null,
    { baseHp, baseAtk, baseDef },
    {
      weaponAtk,
      weaponModifier,
      weaponModifierValue,
      weaponPassiveData,
    },
    selfBuffsData,
    resonanceChainsBuffsData,
    echoStats,
    customBuffs,
    teamBuffsData,
  );

  // Step 4a: Compute AdditionalBase buffs using intermediate stats (self buffs)
  const additionalBaseBuffsData = computeAdditionalBaseBuffs(
    buffsConfig ?? {},
    buffsCharInfo ?? [],
    resonanceChainsConfig ?? {},
    character ?? "",
    intermediateStats.energyRegen,
    intermediateStats.totalCritRate,
    activeStance,
    intermediateStats.totalHp,
    talentData,
  );

  // Step 4b: Compute AdditionalBase buffs using intermediate stats (resonance chains)
  let additionalBaseBuffsDataFromResonanceChains: {
    CritRate: number;
    CritDMG: number;
    ATK: number;
    ATK_FLAT: number;
    specificTalentBuffs?: Record<string, number>;
  } = {
    CritRate: 0,
    CritDMG: 0,
    ATK: 0,
    ATK_FLAT: 0,
  };
  // ignore Augusta, as her additional based buffs for resonance chains are handled in self buffs
  // applying this for her will double the buffs
  if (character !== "Augusta") {
    additionalBaseBuffsDataFromResonanceChains = computeAdditionalBaseBuffs(
      resonanceChainsConfig ?? {},
      resonanceChainsCharInfo ?? [],
      resonanceChainsConfig ?? {},
      character ?? "",
      intermediateStats.energyRegen,
      intermediateStats.totalCritRate,
      activeStance,
      intermediateStats.totalHp,
      talentData,
    );
  }

  const echoSetAdditionalBaseBuffsData = computeAdditionalBaseFromPassives(
    getEnabledAdditionalBasePassives(setBonusLabels, echoSetPassivesConfig),
    intermediateStats.energyRegen,
    intermediateStats.totalCritRate,
    intermediateStats.totalHp,
    talentData,
  );
  const mergedAdditionalBaseBuffsData = mergeAdditionalBaseData(
    additionalBaseBuffsData,
    echoSetAdditionalBaseBuffsData,
  );

  // Step 5: Compute CritOverflow buffs using intermediate stats
  const critOverflowBuffsData = computeCritOverflowBuffs(
    buffsConfig ?? {},
    buffsCharInfo ?? [],
    resonanceChainsConfig ?? {},
    resonanceChainsCharInfo ?? [],
    intermediateStats.totalCritRate,
    activeStance,
  );

  // Step 6a: Merge AdditionalBase and CritOverflow into self buffs (self buffs)
  // generic merge covers every AdditionalBase target attr (CritRate, CritDMG, ATK,
  // ATK_FLAT, EchoDMGBonus, DMGBonus, HealingBonus, elemental bonuses like Fusion, etc.)
  // so new AdditionalBase targets don't need a matching entry added here
  const mergedSelfBuffs: Record<string, any> = { ...selfBuffsData };
  for (const key of Object.keys(mergedAdditionalBaseBuffsData ?? {})) {
    if (key === "specificTalentBuffs") {
      continue;
    }
    mergedSelfBuffs[key] =
      (selfBuffsData?.[key] || 0) + (mergedAdditionalBaseBuffsData?.[key] || 0);
  }
  mergedSelfBuffs.CritDMG =
    (mergedSelfBuffs.CritDMG || 0) + (critOverflowBuffsData?.CritDMG || 0);
  // Step 6b: Merge AdditionalBase and CritOverflow into self buffs (self buffs)
  // ignore augusta though, otherwise it doubles up her buffs
  let mergedResonanceChainsBuffsData = { ...resonanceChainsBuffsData };
  if (character !== "Augusta") {
    mergedResonanceChainsBuffsData = {
      ...resonanceChainsBuffsData,
      CritRate:
        (resonanceChainsBuffsData?.CritRate || 0) +
        (additionalBaseBuffsDataFromResonanceChains?.CritRate || 0),
      CritDMG:
        (resonanceChainsBuffsData?.CritDMG || 0) +
        (additionalBaseBuffsDataFromResonanceChains?.CritDMG || 0) +
        (critOverflowBuffsData?.CritDMG || 0),
      ATK:
        (resonanceChainsBuffsData?.ATK || 0) +
        (additionalBaseBuffsDataFromResonanceChains?.ATK || 0),
      ATK_FLAT:
        (resonanceChainsBuffsData?.ATK_FLAT || 0) +
        (additionalBaseBuffsDataFromResonanceChains?.ATK_FLAT || 0),
      // AdditionalBase modifiers scoped via modifySpecificTalents (e.g. Jingran's
      // SequenceNode3 ATK_FLAT upgrade) resolve into specificTalentBuffs instead
      // of the flat sums above — merge those forward too, or a chain-level
      // per-talent buff silently computes to zero effect (see attacks.ts's
      // matching charResonanceChainsData?.specificTalentBuffs read for ATK_FLAT).
      specificTalentBuffs: Object.assign(
        {},
        resonanceChainsBuffsData?.specificTalentBuffs ?? {},
        additionalBaseBuffsDataFromResonanceChains?.specificTalentBuffs ?? {},
      ),
    };
  }

  // Step 7: Calculate final stats with all buffs
  const finalStats = calcCharStats(
    "All",
    null,
    ignoreBuffs,
    injectEchoStats,
    null,
    { baseHp, baseAtk, baseDef },
    {
      weaponAtk,
      weaponModifier,
      weaponModifierValue,
      weaponPassiveData,
    },
    mergedSelfBuffs,
    mergedResonanceChainsBuffsData,
    echoStats,
    customBuffs,
    teamBuffsData,
  );

  applyCharacterStatEdgeCases(
    finalStats,
    character ?? "",
    resonanceChainsConfig ?? {},
  );

  // Merge AdditionalBase and CritOverflow into breakdown for UI
  const mergedSelfBuffsForBreakdown = {
    ...selfBuffsData,
    ...additionalBaseBuffsData,
    ...echoSetAdditionalBaseBuffsData,
    CritDMG:
      (selfBuffsData?.CritDMG || 0) +
      (additionalBaseBuffsData?.CritDMG || 0) +
      (echoSetAdditionalBaseBuffsData?.CritDMG || 0) +
      (critOverflowBuffsData?.CritDMG || 0),
  };
  // merge the specificTalentBuffs together
  mergedSelfBuffsForBreakdown.specificTalentBuffs = Object.assign(
    {},
    selfBuffsData?.specificTalentBuffs ?? {},
    additionalBaseBuffsData?.specificTalentBuffs ?? {},
    echoSetAdditionalBaseBuffsData?.specificTalentBuffs ?? {},
  );

  return {
    finalStats,
    selfBuffsData: mergedSelfBuffsForBreakdown,
    resonanceChainsBuffsData: mergedResonanceChainsBuffsData,
    additionalBaseBuffsData: mergedAdditionalBaseBuffsData,
    critOverflowBuffsData,
    echoSetAdditionalBaseBuffsData,
  };
};

/**
 * Resolves a character's full stat pipeline from raw buff/passive
 * configuration: steps 1-2 (`computeResonanceChainsBuffs`/`computeSelfBuffs`)
 * plus everything `calculateFinalStatsFromBuffs` does. Callers that need to
 * re-derive final stats many times against the same buff config (e.g. once
 * per echo loadout in the Optimizer) should call `computeResonanceChainsBuffs`/
 * `computeSelfBuffs` once themselves and call `calculateFinalStatsFromBuffs`
 * directly instead, to avoid re-deriving buff data that doesn't depend on
 * echoes at all.
 */
export const calculateAllStats = (context: {
  // Character base stats
  baseHp: number;
  baseAtk: number;
  baseDef: number;

  // Weapon data
  weaponAtk: number;
  weaponModifier: string | null;
  weaponModifierValue: number;
  weaponPassiveData: any;

  // Buff configurations (enabled state)
  buffsConfig: any;
  resonanceChainsConfig: any;
  customBuffs: any;
  teamBuffsData: any;
  echoStats: any;

  // Character data (definitions)
  buffsCharInfo: any[];
  resonanceChainsCharInfo: any[];

  // Character metadata
  character: string;
  talentData: any;
  activeStance?: string | null;

  // Options
  ignoreBuffs?: {
    ignoreTeamBuffs?: boolean;
    ignoreWeaponBuffs?: boolean;
    ignoreEchoes?: boolean;
  };

  // Enemy data
  enemy?: {
    havocBaneStacks?: number;
  };

  // Echo set passives with AdditionalBase modifiers
  setBonusLabels?: (string | null | undefined)[];
  echoSetPassivesConfig?: Record<
    string,
    { isEnabled?: boolean; stacks?: number }
  >;
}): {
  finalStats: any;
  selfBuffsData: any;
  resonanceChainsBuffsData: any;
  additionalBaseBuffsData: any;
  critOverflowBuffsData: any;
  echoSetAdditionalBaseBuffsData: any;
} => {
  const {
    resonanceChainsConfig,
    resonanceChainsCharInfo,
    buffsConfig,
    buffsCharInfo,
    character,
    talentData,
    activeStance = null,
    enemy = {},
  } = context;

  // Step 1: Compute resonance chains buffs (no longer needs base stats)
  const resonanceChainsBuffsData =
    computeResonanceChainsBuffs(
      resonanceChainsConfig ?? {},
      resonanceChainsCharInfo ?? [],
      talentData ?? {},
      activeStance,
    ) || {};

  // Step 2: Compute self buffs (no longer needs base stats)
  const selfBuffsData =
    computeSelfBuffs(
      buffsConfig ?? {},
      buffsCharInfo ?? [],
      resonanceChainsConfig ?? {},
      talentData ?? {},
      character ?? "",
      activeStance,
      enemy,
    ) || {};

  return calculateFinalStatsFromBuffs({
    ...context,
    selfBuffsData,
    resonanceChainsBuffsData,
  });
};
