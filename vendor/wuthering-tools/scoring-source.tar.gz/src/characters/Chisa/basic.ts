export function getCharacterBasicInfo(): CharacterBasicInfo {
  return {
    name: "Chisa",
    rarity: 5,
    weapon: "Broadblades",
    avatarUrl: "Chisa.png",
    gender: "female",
    element: "Havoc",
    havocBane: true,
    image:
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Image/IconRolePile/T_IconRole_Pile_Qianxiao_UI.webp",
    inherentSkillIcons: [
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconQianxiao/SP_IconQianxiaoD1.webp",
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconQianxiao/SP_IconQianxiaoD2.webp",
    ],
    signatureWeapon: "Kumokiri",
    liveResultBarStats: ["totalAtk", "totalCritRate", "totalCritDMG", "energyRegen"],
    suggestedWeapons: [
      { key: "WildfireMark", label: "Alternate" },
      { key: "AgesOfHarvest", label: "Stat stick" },
      { key: "VerdantSummit", label: "Stat stick" },
      { key: "RadianceCleaver", label: "Standard" },
      { key: "Autumntrace", label: "BP" },
      { key: "MeditationsonMercy", label: "4*" },
    ],
  };
}
