export const outroAttacks = {
  name: "Outro Skill: Shadowy Raid",
  description: `<div class="skilldescription">Calcharo summons <span class="Highlight">Phantom</span> to support the active Resonator, clearing the targets in front with a slash. The <span class="Highlight">Phantom's</span> attack deals <span class="Thunder">Electro DMG</span> equal to 195.98%+391.96% of Calcharo's ATK.</div>`,
  icon: "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconKakaluo/SP_IconKakaluoT.webp",
  attacks: [
    {
      key: "ShadowyRaidOutroSkillDMG",
      label: "Shadowy Raid DMG",
      talent: "195.98%+391.96%",
      type: "Outro",
    },
  ],
};
