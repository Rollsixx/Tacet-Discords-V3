export function getCharacterBasicInfo(): CharacterBasicInfo {
  return {
    name: "Cantarella",
    rarity: 5,
    weapon: "Rectifiers",
    avatarUrl: "Cantarella.png",
    gender: "female",
    element: "Havoc",
    spectroFrazzle: false,
    image:
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Image/IconRolePile/T_IconRole_Pile_kanteleila_UI.webp",
    inherentSkillIcons: [
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconKanteleila/SP_IconKanteleilaD1.webp",
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconKanteleila/SP_IconKanteleilaD2.webp",
    ],
    signatureWeapon: "WhispersofSirens",
    liveResultBarStats: ["totalAtk", "totalCritRate", "totalCritDMG", "energyRegen"],
    suggestedWeapons: [
      { key: "RimeDrapedSprouts", label: "Alternate" },
      { key: "Stringmaster", label: "Alternate" },
      { key: "LetheanElegy", label: "Alternate" },
      { key: "CosmicRipples", label: "Standard" },
      { key: "RadiantDawn", label: "BP" },
      { key: "JizhouKeeper", label: "4*" },
    ],
  };
}
