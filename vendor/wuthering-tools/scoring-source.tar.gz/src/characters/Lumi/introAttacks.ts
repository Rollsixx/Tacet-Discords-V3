export const introAttacks = {
  name: "Intro Skill: Special Delivery",
  description: `<div class="skilldescription">Enter <span class="Highlight">Yellow Light Mode</span> and attack the target, dealing <span class="Thunder">Electro DMG</span>.</div>`,
  icon: "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconDengdeng/SP_IconDengdengQTE.webp",
  attacks: [
    {
      key: "SpecialDeliveryDMG",
      label: "Special Delivery DMG",
      talents: {
        "1": "28.34%*3",
        "2": "30.66%*3",
        "3": "32.98%*3",
        "4": "36.24%*3",
        "5": "38.56%*3",
        "6": "41.23%*3",
        "7": "44.95%*3",
        "8": "48.67%*3",
        "9": "52.38%*3",
        "10": "56.33%*3",
      },
      type: "Intro",
    },
  ],
};
