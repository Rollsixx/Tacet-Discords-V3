export function getCharacterBasicInfo(): CharacterBasicInfo {
  return {
    name: "Jingran",
    rarity: 5,
    weapon: "Broadblades",
    avatarUrl: "StayTuned.png",
    gender: "male",
    element: "Fusion",
    image: "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Image/IconRolePile/T_IconRole_Pile_jingran_UI.webp",
    inherentSkillIcons: ["https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconJingran/SP_IconJingranD1.webp","https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconJingran/SP_IconJingranD2.webp"],
    signatureWeapon: "ThousandfoldDeliverance",
    liveResultBarStats: ["totalHp", "totalCritRate", "totalCritDMG", "energyRegen"],
    suggestedWeapons: [
      { key: "ThunderflareDominion", label: "Alternate" },
      { key: "RadianceCleaver", label: "Standard" },
      { key: "AureateZenith", label: "BP" },
      { key: "HeliosCleaver", label: "4*" },
    ],
  };
}
