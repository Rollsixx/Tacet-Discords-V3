export function getCharacterBasicInfo(): CharacterBasicInfo {
  return {
    name: "Lucy",
    rarity: 5,
    weapon: "Pistols",
    avatarUrl: "Lucy.png",
    gender: "female",
    element: "Spectro",
    tuneBreakBoost: 0.1,
    image:
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Image/IconRolePile/T_IconRole_Pile_luxi_UI.webp",
    inherentSkillIcons: [
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconLucy/SP_SkillIconLucyD2.webp",
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconLucy/SP_SkillIconLucyB5.webp",
    ],
    signatureWeapon: "SpectralTrigger",
    liveResultBarStats: ["totalAtk", "totalCritRate", "totalCritDMG", "energyRegen"],
    suggestedWeapons: [
      { key: "LuxUmbra", label: "Alternate" },
      { key: "PhasicHomogenizer", label: "Standard" },
      { key: "TheLastDance", label: "Stat stick" },
      { key: "StaticMist", label: "Standard" },
      { key: "SolarFlame", label: "BP" },
      { key: "RelativisticJet", label: "4*" },
    ],
  };
}
