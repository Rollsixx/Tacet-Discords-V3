export function getCharacterBasicInfo(): CharacterBasicInfo {
  return {
    name: "Augusta",
    rarity: 5,
    weapon: "Broadblades",
    avatarUrl: "Augusta.png",
    gender: "female",
    element: "Electro",
    image:
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Image/IconRolePile/T_IconRole_Pile_aogusita_UI.webp",
    inherentSkillIcons: [
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconAogusita/SP_IconAogusitaD1.webp",
      "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconAogusita/SP_IconAogusitaD2.webp",
    ],
    signatureWeapon: "ThunderflareDominion",
    liveResultBarStats: ["totalAtk", "totalCritRate", "totalCritDMG", "energyRegen"],
    suggestedWeapons: [
      { key: "VerdantSummit", label: "Alternate" },
      { key: "AgesOfHarvest", label: "Alternate" },
      { key: "RadianceCleaver", label: "Standard" },
      { key: "Kumokiri", label: "Stat stick" },
      { key: "AureateZenith", label: "BP" },
      { key: "Autumntrace", label: "BP" },
      { key: "WaningRedshift", label: "4*" },
    ],
  };
}
