export const introAttacks = {
  name: "Intro Skill: Loong's Halo",
  description: `div class="skilldescription">Attack the target, dealing <span class="Light">Spectro DMG</span>.</div>`,
  icon: "https://api.encore.moe/resource/Data/Game/Aki/UI/UIResources/Common/Atlas/SkillIcon/SkillIconJinxi/SP_IconJinxiQTE.webp",
  attacks: [
    {
      key: "LoongsHalo",
      label: "Loong's Halo DMG",
      talents: {
        "1": "80.00%",
        "2": "86.56%",
        "3": "93.12%",
        "4": "102.31%	",
        "5": "108.87%",
        "6": "116.41%",
        "7": "126.91%",
        "8": "137.40%",
        "9": "147.90%",
        "10": "159.05%",
      },
      type: "Intro",
    },
  ],
};
